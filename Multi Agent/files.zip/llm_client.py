"""
llm_client.py
-------------
Satu titik akses ke LLM (Groq).
Semua agent memanggil call_llm() dari sini.
Ganti provider cukup edit file ini saja.
"""

import json
import re
import sys
import requests

from config import API_URL, HEADERS, MAX_TOKENS, MODEL


def call_llm(system_prompt: str, user_message: str) -> str:
    """Kirim prompt ke Groq, kembalikan teks respons mentah."""
    payload = {
        "model"     : MODEL,
        "max_tokens": MAX_TOKENS,
        "messages"  : [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": user_message},
        ],
    }
    try:
        resp = requests.post(API_URL, headers=HEADERS, json=payload, timeout=60)
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"].strip()
    except requests.exceptions.HTTPError as e:
        print(f"\n[LLM ERROR] {e}")
        print(f"  Response: {resp.text[:300]}")
        sys.exit(1)


def parse_json(text: str) -> dict:
    """
    Parse JSON dari respons LLM.
    Toleran terhadap markdown code block (```json ... ```).
    """
    cleaned = re.sub(r"```(?:json)?", "", text).replace("```", "").strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        start = cleaned.find("{")
        end   = cleaned.rfind("}") + 1
        if start != -1 and end > start:
            return json.loads(cleaned[start:end])
        raise ValueError(f"Gagal parse JSON dari respons LLM:\n{text[:300]}")
