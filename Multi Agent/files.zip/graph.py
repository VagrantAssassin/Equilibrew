"""
graph.py
--------
Definisi graph LangGraph untuk sistem Multi-Agent Tea'n Brew.

Graph Phase 1 (via app.stream):
  START → profile_agent → dialogue_pesanan → critic_agent
        → [loop revisi jika gagal]
        → END

Alur interaktif (ordering + curhat) dikelola di main.py menggunakan
fungsi utilitas dari modul ini (jalankan_critic_loop, update_mood, dll.)
karena membutuhkan human-in-the-loop yang tidak bisa di-pause di LangGraph.

Fungsi utilitas yang diekspor untuk main.py:
  - jalankan_dialog_state(state, fn_generate) → run agent + critic loop
  - update_mood(state)                        → update mood + riwayat
"""

import random
from langgraph.graph import StateGraph, START, END

from state  import GameState
from config import MAX_REVISI, RONDE_MIN, RONDE_MAX, MOOD_DELTA, MOOD_MIN, MOOD_MAX

import agents.profile_agent  as profile_agent
import agents.dialogue_agent as dialogue_agent
import agents.critic_agent   as critic_agent


# ─────────────────────────────────────────────────────────────────────────────
# FUNGSI UTILITAS — dipakai oleh main.py untuk sesi interaktif
# ─────────────────────────────────────────────────────────────────────────────

def jalankan_dialog_state(state: dict, fn_generate) -> dict:
    """
    Jalankan satu dialog state lengkap dengan actor-critic loop.

    Alur:
      fn_generate(state) → dialog
      critic_agent.run(state) → validasi
      [jika gagal & belum max revisi] → critic_agent.run_revisi(state) → ulang
      [lulus atau max revisi] → kembalikan state final

    Args:
      state      : GameState saat ini
      fn_generate: fungsi agent (dialogue_agent.run_pesanan, run_curhat, dll.)
    """
    # Generate dialog
    updates = fn_generate(state)
    state.update(updates)

    # Actor-Critic loop
    for i in range(MAX_REVISI + 1):
        kritik = critic_agent.run(state)
        state.update(kritik)

        if state.get("critic_lulus", False):
            break

        if i >= MAX_REVISI:
            break  # diterima paksa

        # Revisi
        revisi = critic_agent.run_revisi(state)
        state.update(revisi)

    return state


def update_mood(state: dict) -> dict:
    """
    Update mood berdasarkan jawaban pemain dan simpan ke riwayat.
    Dipanggil di main.py setelah pemain memilih jawaban curhat.
    """
    jawaban   = state.get("jawaban_pemain", "")
    pilihan   = state.get("pilihan_jawaban", [])
    mood_lama = state.get("mood", 50)

    # Cari nada dari teks jawaban yang dipilih
    nada = "neutral"
    for p in pilihan:
        if p["teks"] == jawaban:
            nada = p["nada"]
            break

    delta     = MOOD_DELTA.get(nada, 0)
    mood_baru = max(MOOD_MIN, min(MOOD_MAX, mood_lama + delta))

    # Tambah ke riwayat (short-term memory sesi curhat)
    riwayat = list(state.get("riwayat", []))
    riwayat.append({
        "ronde"         : state.get("ronde_sekarang", 1),
        "dialog_npc"    : state.get("dialog_npc", ""),
        "jawaban_pemain": jawaban,
        "nada"          : nada,
        "mood_sebelum"  : mood_lama,
        "mood_sesudah"  : mood_baru,
    })

    return {
        "mood"   : mood_baru,
        "riwayat": riwayat,
    }


def random_total_ronde() -> int:
    return random.randint(RONDE_MIN, RONDE_MAX)


# ─────────────────────────────────────────────────────────────────────────────
# GRAPH PHASE 1 — Profile + Pesanan Awal
# ─────────────────────────────────────────────────────────────────────────────

def _node_dialogue_pesanan(state: GameState) -> dict:
    return dialogue_agent.run_pesanan(state)


def _node_critic(state: GameState) -> dict:
    return critic_agent.run(state)


def _node_critic_revisi(state: GameState) -> dict:
    return critic_agent.run_revisi(state)


def _route_critic(state: GameState) -> str:
    """Router setelah Critic Agent: lanjut atau revisi."""
    lulus  = state.get("critic_lulus", False)
    revisi = state.get("revisi_ke", 0)
    if lulus or revisi > MAX_REVISI:
        return END
    return "critic_revisi"


def build_graph() -> StateGraph:
    """
    Graph Phase 1: Profile Agent → Dialogue Pesanan → Critic Loop → END

    Dijalankan via app.stream() di main.py untuk menghasilkan profil NPC
    dan dialog pesanan awal sebelum fase interaktif dimulai.
    """
    g = StateGraph(GameState)

    g.add_node("profile_agent",    profile_agent.run)
    g.add_node("dialogue_pesanan", _node_dialogue_pesanan)
    g.add_node("critic_agent",     _node_critic)
    g.add_node("critic_revisi",    _node_critic_revisi)

    g.add_edge(START, "profile_agent")
    g.add_edge("profile_agent", "dialogue_pesanan")
    g.add_edge("dialogue_pesanan", "critic_agent")

    g.add_conditional_edges(
        "critic_agent",
        _route_critic,
        {"critic_revisi": "critic_revisi", END: END}
    )
    g.add_edge("critic_revisi", "critic_agent")

    return g.compile()


# Singleton graph
app = build_graph()
