"""
agents/dialogue_agent.py
------------------------
Dialogue Agent — bertanggung jawab atas SEMUA produksi dialog NPC.

Menangani 5 dialog state sesuai skenario game Tea'n Brew:
  run_pesanan()       → state "pesanan"       : NPC memesan minuman
  run_pesanan_salah() → state "pesanan_salah" : NPC bereaksi saat pesanan salah
  run_marah()         → state "marah"         : NPC marah dan pergi (max fails)
  run_berhasil()      → state "berhasil"      : NPC puas, pesanan benar
  run_curhat()        → state "curhat"        : Dialog per ronde + 3 pilihan
  run_reaksi()        → sub-state curhat      : Reaksi NPC setelah pemain menjawab

Agent ini beroperasi terus-menerus mengikuti alur game hingga pelanggan
marah (dialog_marah) atau sesi curhat selesai.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from config     import GAYA_BAHASA, MENU_MINUMAN
from llm_client import call_llm, parse_json
from state      import GameState
from agents.profile_agent import build_ocean_desc


def _mood_ctx(mood: int) -> str:
    """Terjemahkan nilai mood ke konteks narasi untuk prompt."""
    if mood >= 70:
        return "NPC sedang senang dan terbuka, dialog lebih ekspresif dan hangat."
    elif mood >= 40:
        return "NPC dalam kondisi netral, bercerita apa adanya."
    else:
        return "NPC sedang kesal atau kecewa, dialog lebih singkat, nada dingin atau defensif."


def _riwayat_ctx(riwayat: list) -> str:
    """Format riwayat percakapan sebagai konteks untuk prompt curhat."""
    if not riwayat:
        return ""
    lines = ["\nRiwayat percakapan sebelumnya:"]
    for r in riwayat:
        lines.append(
            f"  Ronde {r['ronde']}: NPC: \"{r['dialog_npc'][:60]}...\"\n"
            f"           Pemain: \"{r['jawaban_pemain']}\" "
            f"(mood {r['mood_sebelum']}→{r['mood_sesudah']})"
        )
    return "\n".join(lines)


def _base_system(ocean: dict, usia: str) -> str:
    """System prompt dasar yang sama untuk semua dialog state."""
    return f"""Kamu adalah Dialogue Agent dalam game visual novel café "Tea'n Brew".
Tugasmu menghasilkan dialog NPC yang autentik dan mencerminkan kepribadian OCEAN-nya.

Kepribadian NPC:
{build_ocean_desc(ocean)}

Gaya bahasa: {GAYA_BAHASA.get(usia, 'natural')}
Kembalikan HANYA JSON valid, tanpa teks lain."""


# ── STATE 1: Pesanan ──────────────────────────────────────────────────────────

def run_pesanan(state: GameState) -> dict:
    """
    NPC datang dan memesan minuman.
    Pilihan minuman harus sesuai suasana hati / masalah NPC.
    """
    ocean = state["ocean"]
    system = _base_system(ocean, state["usia"])

    user = f"""NPC: {state['nama']} ({state['usia']}, {state['gender']})
Background   : {state['background']}
Masalah      : {state['masalah_hari_ini']}
Menu tersedia: {', '.join(MENU_MINUMAN)}

Buat dialog NPC memesan minuman. Pilih minuman yang sesuai suasana hati/masalahnya.
Dialog harus mencerminkan kepribadian OCEAN NPC.

Format JSON:
{{
  "minuman_dipesan": "nama minuman dari menu",
  "dialog_pesanan": "dialog NPC memesan..."
}}"""

    raw    = call_llm(system, user)
    result = parse_json(raw)

    return {
        "minuman_dipesan": result["minuman_dipesan"],
        "dialog_pesanan" : result["dialog_pesanan"],
        "dialog_state"   : "pesanan",
        "konteks_critic" : "pesanan",
        "revisi_ke"      : 0,
    }


# ── STATE 2: Pesanan Salah ────────────────────────────────────────────────────

def run_pesanan_salah(state: GameState) -> dict:
    """
    NPC bereaksi saat pemain menyajikan minuman yang salah.
    Tingkat kemarahan dipengaruhi fail_count dan OCEAN (Agreeableness/Neuroticism).
    """
    ocean     = state["ocean"]
    fail_count = state.get("fail_count", 1)
    max_fails  = state.get("max_fails", 2)
    system     = _base_system(ocean, state["usia"])

    # Intensitas kemarahan meningkat seiring fail_count
    intensitas = "sedikit kecewa" if fail_count == 1 else \
                 "cukup kesal"    if fail_count == 2 else \
                 "sangat kesal, hampir marah"

    user = f"""NPC: {state['nama']} ({state['usia']}, {state['gender']})
Pesanan NPC: {state.get('minuman_dipesan', 'teh')}
Kesalahan ke-{fail_count} dari maksimal {max_fails} kali.
Intensitas reaksi: {intensitas}

Pemain baru saja menyajikan minuman yang SALAH.
Buat dialog NPC bereaksi terhadap pesanan yang salah.
Sesuaikan tingkat kekesalan dengan OCEAN dan intensitas di atas.

Format JSON:
{{
  "dialog_pesanan_salah": "reaksi NPC saat pesanan salah..."
}}"""

    raw    = call_llm(system, user)
    result = parse_json(raw)

    return {
        "dialog_pesanan_salah": result["dialog_pesanan_salah"],
        "dialog_state"        : "pesanan_salah",
        "konteks_critic"      : "pesanan_salah",
        "revisi_ke"           : 0,
    }


# ── STATE 3: Marah (max fails tercapai) ──────────────────────────────────────

def run_marah(state: GameState) -> dict:
    """
    NPC marah dan memutuskan pergi setelah mencapai batas fail.
    Pemain mendapat punishment score -10 (ditangani Unity).
    """
    ocean  = state["ocean"]
    system = _base_system(ocean, state["usia"])

    user = f"""NPC: {state['nama']} ({state['usia']}, {state['gender']})
Pesanan NPC: {state.get('minuman_dipesan', 'teh')}
NPC sudah salah {state.get('max_fails', 2)} kali dan sudah kehabisan sabar.

Buat dialog NPC yang MARAH dan memutuskan untuk pergi meninggalkan kafe.
Dialog harus mencerminkan kepribadian OCEAN namun tetap menunjukkan kekecewaan/kemarahan.
Jangan terlalu panjang — maksimal 2 kalimat.

Format JSON:
{{
  "dialog_marah": "dialog NPC marah dan pergi..."
}}"""

    raw    = call_llm(system, user)
    result = parse_json(raw)

    return {
        "dialog_marah" : result["dialog_marah"],
        "dialog_state" : "marah",
        "konteks_critic": "marah",
        "revisi_ke"    : 0,
    }


# ── STATE 4: Berhasil (pesanan benar) ────────────────────────────────────────

def run_berhasil(state: GameState) -> dict:
    """
    NPC puas karena pesanan benar.
    Menjadi transisi ke sesi curhat.
    """
    ocean  = state["ocean"]
    system = _base_system(ocean, state["usia"])

    user = f"""NPC: {state['nama']} ({state['usia']}, {state['gender']})
Pesanan NPC: {state.get('minuman_dipesan', 'teh')}
Pemain baru saja menyajikan minuman yang BENAR dan sesuai pesanan.

Buat dialog NPC yang puas dan senang menerima pesanannya.
Dialog bisa sedikit membuka percakapan (hint akan bercerita selanjutnya).
Sesuaikan dengan kepribadian OCEAN.

Format JSON:
{{
  "dialog_berhasil": "dialog NPC puas dengan pesanan..."
}}"""

    raw    = call_llm(system, user)
    result = parse_json(raw)

    return {
        "dialog_berhasil": result["dialog_berhasil"],
        "dialog_state"   : "berhasil",
        "konteks_critic" : "berhasil",
        "revisi_ke"      : 0,
    }


# ── STATE 5: Curhat (per ronde) ───────────────────────────────────────────────

def run_curhat(state: GameState) -> dict:
    """
    NPC bercerita / curhat untuk satu ronde.
    Mood dan riwayat percakapan sebelumnya mempengaruhi isi dialog.
    Ronde terakhir diarahkan ke penutup/resolusi.
    """
    ocean       = state["ocean"]
    mood        = state.get("mood", 50)
    ronde       = state.get("ronde_sekarang", 1)
    total_ronde = state.get("total_ronde", 3)
    riwayat     = state.get("riwayat", [])
    is_last     = (ronde == total_ronde)
    system      = _base_system(ocean, state["usia"])

    user = f"""NPC: {state['nama']} ({state['usia']}, {state['gender']})
Masalah: {state['masalah_hari_ini']}
Mood NPC saat ini: {mood}/100 — {_mood_ctx(mood)}
Ronde: {ronde} dari {total_ronde} {"← RONDE TERAKHIR: buat dialog penutup/resolusi" if is_last else ""}
{_riwayat_ctx(riwayat)}

Buat:
1. dialog_npc     : NPC melanjutkan cerita/curhatnya (1–3 kalimat sesuai mood & OCEAN)
2. pilihan_jawaban: 3 opsi respons pemain dengan nada berbeda

Catatan: mood rendah membuat dialog lebih tertutup dan singkat.

Format JSON:
{{
  "dialog_npc": "...",
  "pilihan_jawaban": [
    {{"id": 1, "teks": "...", "nada": "satisfy"}},
    {{"id": 2, "teks": "...", "nada": "neutral"}},
    {{"id": 3, "teks": "...", "nada": "angry"}}
  ]
}}"""

    raw    = call_llm(system, user)
    result = parse_json(raw)

    return {
        "dialog_npc"     : result["dialog_npc"],
        "pilihan_jawaban": result["pilihan_jawaban"],
        "dialog_state"   : "curhat",
        "konteks_critic" : "curhat",
        "revisi_ke"      : 0,
    }


# ── SUB-STATE: Reaksi (setelah pemain menjawab) ───────────────────────────────

def run_reaksi(state: GameState) -> dict:
    """
    NPC bereaksi singkat setelah pemain memberikan jawaban di sesi curhat.
    Dipanggil setelah mood di-update oleh update_mood().
    """
    ocean  = state["ocean"]
    mood   = state.get("mood", 50)
    system = _base_system(ocean, state["usia"])

    user = f"""NPC: {state['nama']} | Mood sekarang: {mood}/100
NPC baru saja berkata: "{state.get('dialog_npc', '')}"
Pemain menjawab: "{state.get('jawaban_pemain', '')}"
Kondisi mood: {_mood_ctx(mood)}

Buat reaksi singkat NPC (1–2 kalimat) terhadap jawaban pemain.
Reaksi harus mencerminkan mood saat ini dan kepribadian OCEAN.

Format JSON:
{{
  "reaksi_npc": "..."
}}"""

    raw    = call_llm(system, user)
    result = parse_json(raw)

    return {"reaksi_npc": result["reaksi_npc"]}
