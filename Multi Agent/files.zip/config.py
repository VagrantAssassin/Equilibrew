"""
config.py
---------
Semua konfigurasi sistem dibaca dari file .env menggunakan python-dotenv.
Tidak ada credential yang di-hardcode di sini.

Cara setup:
  1. cp .env.example .env
  2. Isi GROQ_API_KEY di file .env
  3. Jalankan: python main.py
"""

import os
import sys
from dotenv import load_dotenv

# Muat variabel dari file .env
load_dotenv()

# ── API ───────────────────────────────────────────────────────────────────────
API_URL = os.getenv("GROQ_API_URL", "https://api.groq.com/openai/v1/chat/completions")
MODEL   = os.getenv("GROQ_MODEL",   "llama-3.3-70b-versatile")
API_KEY = os.getenv("GROQ_API_KEY", "")

if not API_KEY:
    print("\n[ERROR] GROQ_API_KEY tidak ditemukan!")
    print("  1. Salin file: cp .env.example .env")
    print("  2. Isi GROQ_API_KEY di file .env dengan key dari console.groq.com")
    sys.exit(1)

HEADERS = {
    "Content-Type" : "application/json",
    "Authorization": f"Bearer {API_KEY}",
}

# ── LLM ───────────────────────────────────────────────────────────────────────
MAX_TOKENS = int(os.getenv("MAX_TOKENS", "1500"))

# ── ACTOR-CRITIC ──────────────────────────────────────────────────────────────
MAX_REVISI       = int(os.getenv("MAX_REVISI", "2"))
CRITIC_THRESHOLD = int(os.getenv("CRITIC_THRESHOLD", "70"))

# ── MOOD ──────────────────────────────────────────────────────────────────────
MOOD_AWAL  = int(os.getenv("MOOD_AWAL", "50"))   # nanti diganti inputan Unity
MOOD_MIN   = 0
MOOD_MAX   = 100
MOOD_DELTA = {"satisfy": +10, "neutral": 0, "angry": -10}

# ── SESI CURHAT ───────────────────────────────────────────────────────────────
RONDE_MIN = int(os.getenv("RONDE_MIN", "3"))
RONDE_MAX = int(os.getenv("RONDE_MAX", "5"))

# ── DATA GAME (dari Tabel 3.2 & 3.3 skripsi) ─────────────────────────────────
# Profile pelanggan sesuai Table 3.2
KATEGORI_USIA = ["remaja", "dewasa", "orang tua"]

# Gaya bahasa per kelompok usia
GAYA_BAHASA = {
    "remaja"    : "santai, gaul, pakai kata seperti 'kak', 'bro', 'sih', 'dong', 'tuh'",
    "dewasa"    : "lugas, sopan tapi natural, kadang sedikit formal",
    "orang tua" : "formal, bijak, sering pakai 'nak', kalimat panjang dan reflektif",
}

# Menu minuman dari Tabel 3.3
MENU_MINUMAN = [
    "Black Tea", "Green Tea", "Mint Tea", "Lavender Tea",
    "Jasmine Tea", "Milk Tea", "Mint Milk Tea", "Matcha Latte",
    "Honey Tea", "Golden Jasmine Tea", "Apple Tea", "Apple Green Tea",
]

# Minuman aktif untuk saat ini (3 pilihan, nanti input dari Unity)
# Ganti isi list ini sesuai minuman yang diaktifkan di Unity
MENU_MINUMAN = [
    "Black Tea",
    "Mint Tea",
    "Green Tea",
]
